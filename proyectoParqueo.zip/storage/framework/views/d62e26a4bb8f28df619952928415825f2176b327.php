<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('Style/listaSol.css')); ?>">
</head>

<body>
  <!--
<div class="col-auto my-1">
 <a href="<?php echo e(route('solicitud.create')); ?>" class="btn btn-success">nuevo</a>
     </div>
-->
  <div class="container">
    <center>
      <label for="Titulo" class="Titulo">Lista de clientes</label>
    </center>
    <div class="row">
      <div class="col-lx-12">
        <form action="<?php echo e(route('clientes.index')); ?>" method="get">
          <div class="form-row">
            <div class="col-sm-4 my-1">
              <input type="text" class="form-control" name="texto" >
            </div>
            <div class="col-auto my-1">
              <input type="submit" class="btn btn-primary" value="buscar">
            </div>
          </div>
        </form>
      </div>
      <div class="col-lx-12">
        <div class="table-responsive">
          <table class="table table-striped">
            
              
                <th></th>
                <th>Codigo SIS</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Email</th>
                <th>Telefono</th>
                <th>Placa</th>
                <th>Tipo de vehiculo</th>
                <th>Puesto de Parqueo</th>
              
            
            <tbody>
              <?php if(count($clientess)<=0): ?>
              <tr>
                <td colspan="8">No hay resultados </td>
              </tr>
              <?php else: ?>

              <?php $__currentLoopData = $clientess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="<?php echo e(route('clientes.edit',$cli->CodigoSIS)); ?>" class="btn btn-warning btn-sm">Editar</a>
                  <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($cli->CodigoSIS); ?>">
                    Eliminar
                  </button>
                </td>
                <td><?php echo e($cli->CodigoSIS); ?></td>
                <td><?php echo e($cli->Nombre); ?></td>
                <td><?php echo e($cli->Apellido); ?></td>
                <td><?php echo e($cli->Email); ?></td>
                <td><?php echo e($cli->Telefono); ?></td>
                <td><?php echo e($cli->Placa); ?></td>
                <td><?php echo e($cli->Vehiculo); ?></td>
                <td><?php echo e($cli->Puesto); ?></td>
              </tr>
              <?php echo $__env->make('cliente.eliminarcliente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
          <?php echo e($clientess->links()); ?>

        </div>
      </div>
    </div>
    <br>
    <div class="col-auto my-1 ">
      <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Volver a menu</a>
      <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary">Ir a registro</a>
    </div>
    <br>
  </div>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wi 10\Antonio\proyectoParqueo\resources\views/cliente/listacliente.blade.php ENDPATH**/ ?>