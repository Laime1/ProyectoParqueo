<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('Style/fondo.css')); ?>">


</head>
<?php $__env->startSection('content'); ?>
<body>
<h1>Bienvenidos al sistema de estacionamiento de FCyT-UMSS</h1>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wi 10\Antonio\proyectoParqueo\resources\views/inicio.blade.php ENDPATH**/ ?>