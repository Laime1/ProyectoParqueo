<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Correo</title>
    <link rel="stylesheet" href="<?php echo e(asset('Style/mensajes.css')); ?>">

</head>
<body>
    <?php if(session('success')): ?>
    <li><?php echo e(session('success')); ?></li>
    <?php endif; ?>
<form action="<?php echo e(url('/clientess')); ?>" method="get">

<label for="">Enviar a:</label>
<input type="text" name="sis" id=""  oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); this.value = this.value.replace(/[^0-9]/,'')" minlength ="9" maxlength ="10" placeholder= "Ingrese CodigoSIS"  required>
<input type="submit" value="buscar">

</form>
<h2>Envio de notificaciones</h2>
    <form method="POST" action="/enviar-correo">
        <?php echo csrf_field(); ?>
        <?php if(isset($datos)): ?>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label for=""><b>Nombre:</b></label>
        <label for="nombre"><?php echo e($dato->Nombre); ?></label><br>
        <label for=""><b>CodigoSIS:</b></label>
        <label for=""><?php echo e($dato->CodigoSIS); ?></label><br>
        <label for=""><b>Email:</b></label>
        <label for=""><?php echo e($dato->Email); ?></label><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <label for=""><b>Mensaje:</b></label><br>
        <textarea name="mensaje" id="mensaje" rows="5" ></textarea>
        <button type="submit">Enviar correo</button>
        <?php endif; ?>
    </form>
</body>
</html>
<?php /**PATH C:\Users\wi 10\Antonio\proyectoParqueo\resources\views/email/mail/correo.blade.php ENDPATH**/ ?>