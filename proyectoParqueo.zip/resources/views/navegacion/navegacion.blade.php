<ul>
    <li><a href="/solicitud">solicitud</a></li>
    <li><a href="/cliente">cliente</a></li>
</ul>