<h1>Correo enviado desde SerApps</h1>
<p>
    {{$mensaje}}
</p>