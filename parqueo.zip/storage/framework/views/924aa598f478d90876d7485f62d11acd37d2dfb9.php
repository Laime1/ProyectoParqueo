<!DOCTYPE html>
<html>
<head>
    <title>Crear Queja o Reclamo</title>
    <link rel="stylesheet" href="<?php echo e(asset('Style/solicitud.css')); ?>">

</head>
<?php $__env->startSection('content'); ?>

<body>
    <h1> Queja o Reclamo</h1>
    <?php if(session('success')): ?>
    <li><?php echo e(session('success')); ?></li>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('quejas.store')); ?>">
        <?php echo csrf_field(); ?>
        
        <label for="nombre">Nombre:</label>
        <input type="text" name="sis" id="sis"  oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); this.value = this.value.replace(/[^0-9]/,'')" minlength ="9" maxlength ="10" placeholder= "Ingrese CodigoSIS"  required>

        
        <label for="descripcion">Descripción:</label><br>
        <textarea name="descripcion" id="descripcion" rows="5" required></textarea><br>

        
        
        <input type="submit" value="Enviar Queja o Reclamo">
    </form>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch/Documents/proyectosLaravel/tercerSprint/ProyectoParqueo/resources/views/reclamos/create.blade.php ENDPATH**/ ?>