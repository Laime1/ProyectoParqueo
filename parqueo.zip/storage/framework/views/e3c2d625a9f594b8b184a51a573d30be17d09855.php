<!DOCTYPE html>
<html>
<head>
    <title>Registro de Salida</title>
    <link rel="stylesheet" href="<?php echo e(asset('Style/solicitud.css')); ?>">
</head>
<?php $__env->startSection('content'); ?>
<body>
    <?php if(session('error')): ?>
    <li><?php echo e(session('error')); ?></li>
    <?php endif; ?>
    <?php if(session('message')): ?>
    <li><?php echo e(session('message')); ?></li>
    <?php endif; ?>

    <h1>Registro de Salida</h1>
    
    <form method="POST" action="<?php echo e(url('/control/salidas')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="codigoSIS">Código SIS:</label>
        <input type="text" name="codigoSIS" id="codigoSIS" required><br>
        <label for="">Hora de Salida:</label><br>
        <input type="datetime-local" name="horaSalida" id="horaSalida" value="<?php echo e(now()); ?>"><br>
        <input type="submit" value="Registrar Salida">
    </form>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch/Documents/proyectosLaravel/tercerSprint/ProyectoParqueo/resources/views/salidas_entradas/salida.blade.php ENDPATH**/ ?>