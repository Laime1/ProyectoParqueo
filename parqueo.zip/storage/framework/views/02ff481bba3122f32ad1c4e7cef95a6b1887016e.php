<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mapa del parqueo</title>
    <link rel="stylesheet" href="<?php echo e(asset('Style/maquetado.css')); ?>">

</head>
<?php $__env->startSection('content'); ?>
<body>
    <div>
      
     <div id ="contenedorBotones4">
     <?php $__currentLoopData = $puestoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(($puesto->numero)>=8&&($puesto->numero)<=19): ?>
      <?php $__currentLoopData = $clientess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(($puesto->cliente_sis)==($cliente->CodigoSIS)): ?>
         <button class="button" onmouseover="mostrarDialogo('<?php echo e($cliente->Nombre); ?>','<?php echo e($cliente->Apellido); ?>','<?php echo e($cliente->Placa); ?>','<?php echo e($cliente->NombreSecundario); ?>','<?php echo e($cliente->ApellidoSecundario); ?>')"  onmouseout="cerrarDialogo()" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>
         <?php continue 2; ?>
         <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <button class="button" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>

      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     </div>

     <div id ="contenedorBotones5">
     <?php $__currentLoopData = $puestoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(($puesto->numero)>=32 &&($puesto->numero)<=53): ?>
      <?php $__currentLoopData = $clientess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(($puesto->cliente_sis)==($cliente->CodigoSIS)): ?>
         <button class="button" onmouseover="mostrarDialogo('<?php echo e($cliente->Nombre); ?>','<?php echo e($cliente->Apellido); ?>','<?php echo e($cliente->Placa); ?>','<?php echo e($cliente->NombreSecundario); ?>','<?php echo e($cliente->ApellidoSecundario); ?>')"  onmouseout="cerrarDialogo()" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>
         <?php continue 2; ?>
         <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="button" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>
      <?php endif; ?> 
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     
     </div>

     <div id ="contenedorBotones2">
     <?php $__currentLoopData = $puestoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if(($puesto->numero)>=20&&($puesto->numero)<=31): ?>
       <?php $__currentLoopData = $clientess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(($puesto->cliente_sis)==($cliente->CodigoSIS)): ?>
         <button class="button" onmouseover="mostrarDialogo('<?php echo e($cliente->Nombre); ?>','<?php echo e($cliente->Apellido); ?>','<?php echo e($cliente->Placa); ?>','<?php echo e($cliente->NombreSecundario); ?>','<?php echo e($cliente->ApellidoSecundario); ?>')"  onmouseout="cerrarDialogo()" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>
         <?php continue 2; ?>
         <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <button class="button" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>

       <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     </div>

     <div id ="contenedorBotones1">
     <?php $__currentLoopData = $puestoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if(($puesto->numero)>=20&&($puesto->numero)<=25): ?>
       <?php $__currentLoopData = $clientess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(($puesto->cliente_sis)==($cliente->CodigoSIS)): ?>
         <button class="button" onmouseover="mostrarDialogo('<?php echo e($cliente->Nombre); ?>','<?php echo e($cliente->Apellido); ?>','<?php echo e($cliente->Placa); ?>','<?php echo e($cliente->NombreSecundario); ?>','<?php echo e($cliente->ApellidoSecundario); ?>')"  onmouseout="cerrarDialogo()" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>
         <?php continue 2; ?>
         <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <button class="button" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>

       <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     </div>

     <div id ="contenedorBotones3">
     <?php $__currentLoopData = $puestoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if(($puesto->numero)>=1&&($puesto->numero)<=7): ?>
        <?php $__currentLoopData = $clientess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(($puesto->cliente_sis)==($cliente->CodigoSIS)): ?>
         <button class="button" onmouseover="mostrarDialogo('<?php echo e($cliente->Nombre); ?>','<?php echo e($cliente->Apellido); ?>','<?php echo e($cliente->Placa); ?>','<?php echo e($cliente->NombreSecundario); ?>','<?php echo e($cliente->ApellidoSecundario); ?>')"  onmouseout="cerrarDialogo()" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>
         <?php continue 2; ?>
         <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <button class="button" onclick="mostrarModal('<?php echo e($puesto->numero); ?>','<?php echo e($puesto->cliente_sis); ?>','<?php echo e($puesto->cliente_secundario); ?>')" style="background-color:<?php echo e($puesto->color); ?>;"><?php echo e(($puesto->numero)); ?></button>
         <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     </div>
       
    </div>
    

<div id="miModal" class="modal">
  <div class="modal-contenido">
     <span onclick="cerrarModal()" class="modal-cerrar">&times;</span>
      <h2>Agregar a:</h2>
      <form class="formulario-modal" action="<?php echo e(url('/asignar')); ?>" method="get" >
       <label>Puesto</label>
       <input id="puesto" type="text" name="puesto">
       <label>Codigo SIS Titular:</label>
       <input type="text" name="sis" id="sis"  oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); this.value = this.value.replace(/[^0-9]/,'')" minlength ="9" maxlength ="10" placeholder= "Ingrese CodigoSIS"  required>
       <label>Codigo SIS Secundario:</label>
       <input type="text" name="sis2" id="sis2"  oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); this.value = this.value.replace(/[^0-9]/,'')" minlength ="9" maxlength ="10" placeholder= "Ingrese CodigoSIS"  >
       <label id="">Desde:</label>
       <input type="date" id="inicio" name="inicio" value="<?php echo e(date('Y-m-d')); ?>" required></input>
       <label id="">Hasta:</label>
       <input type="date" id="fin" name="fin" value="<?php echo e(date('Y-m-d')); ?>" required></input>
       <input type="submit" name="accion" value="vaciar sitio">
       <input type="submit" name="accion" value="asignar sitio">
    </form>
  </div>
</div>

        <div id="myDialog" >
                <h3>Información</h3>
               <label><b>Nombre: </b></label>
               <label id="nombre"></label>
               <label id="apellido"></label><br>
               <label><b>Placa: </b></label>
               <label id="placa"></label><br>
               <label><b>Compartido con:</b></label>
               <label id="nombres"></label>
               <label id="apellidos"></label>
               
        </div>
        <script>
          function mostrarDialogo($n,$a,$p,$ns,$as){ 
          var dialog = document.getElementById('myDialog');
             dialog.style.display = 'block';
            document.getElementById("nombre").innerHTML=$n;
            document.getElementById("apellido").innerHTML=$a;
            document.getElementById("placa").innerHTML=$p;
            document.getElementById("nombres").innerHTML=$ns;
            document.getElementById("apellidos").innerHTML=$as;
          }
          function cerrarDialogo(){ 
          var dialog = document.getElementById('myDialog');
             dialog.style.display = 'none';
          }

        </script>


<script>
function mostrarModal($a,$s,$cs) {
  document.getElementById("miModal").style.display = "block";
  //var contenidoBoton = document.getElementById("puestos").innerHTML;
  document.getElementById("puesto").value = $a;
  document.getElementById("sis").value = $s;
  document.getElementById("sis2").value = $cs;
  //document.getElementById("nombre").innerHTML=$n;

}
function cerrarModal() {
  document.getElementById("miModal").style.display = "none";
}
function vaciarCitio(){

}
</script>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch/Documents/proyectosLaravel/tercerSprint/ProyectoParqueo/resources/views/maquetado/maquetado.blade.php ENDPATH**/ ?>