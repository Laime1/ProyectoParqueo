<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Control de pagos</h1>
    <form action="<?php echo e(url('/pagoss')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">Codigo SIS:</label><br>
        <?php if(isset($datos)): ?>
          <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <input type="text" name="sis" id="sis"  oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); this.value = this.value.replace(/[^0-9]/,'')" minlength ="9" maxlength ="10" placeholder= "Ingrese CodigoSIS" value="<?php echo e($dato->CodigoSIS); ?>" required> 
          <input type="submit" name="accion" value="Buscar"><br>
          <label for="">Pagar desde</label>
          <input type="date" name="desde" id="desde" value="<?php echo e($dato->pago_hasta); ?>">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
          <?php if(empty($datos)): ?>
          <input type="text" name="sis" id="sis"  oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); this.value = this.value.replace(/[^0-9]/,'')" minlength ="9" maxlength ="10" placeholder= "Ingrese CodigoSIS"  required> 
          <input type="submit" name="accion" value="Buscar"><br>
          <label for="">Pagar desde</label>

           <input type="date" name="desde" id="desde" value="<?php echo e(date('Y-m-d')); ?>"> 
          <?php endif; ?>
        <?php else: ?>
          <input type="text" name="sis" id="sis"  oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); this.value = this.value.replace(/[^0-9]/,'')" minlength ="9" maxlength ="10" placeholder= "Ingrese CodigoSIS"  required> 
          <input type="submit" name="accion" value="Buscar"><br>
          <label for="">Pagar desde</label>
          <input type="date" name="desde" id="desde" value="<?php echo e(date('Y-m-d')); ?>"> 
        <?php endif; ?>

        <label for="">hasta</label>
        <?php if(isset($monto)): ?>
          <?php if(isset($hasta)): ?>
           <input type="date" name="hasta" id="hasta" value="<?php echo e($hasta); ?>"><br>

          <?php endif; ?>
           <label for="">Monto a Pagar:</label>
           <input type="text" name="monto" id="monto" value="<?php echo e($monto); ?>">
        <?php else: ?>
           <input type="date" name="hasta" id="hasta" value="<?php echo e(date('Y-m-d')); ?>"><br>
           <label for="">Monto a Pagar:</label>
           <input type="text" name="monto" id="monto">
        <?php endif; ?>
        <input type="submit" name="accion" value="Calcular"><br>
        <input type="submit" name="accion"  value="cobrar">
        

    </form>
</body>
</html><?php /**PATH /home/arch/Documents/proyectosLaravel/tercerSprint/ProyectoParqueo/resources/views/pagos/index.blade.php ENDPATH**/ ?>