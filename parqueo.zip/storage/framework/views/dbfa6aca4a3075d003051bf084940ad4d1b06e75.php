<!DOCTYPE html>
<html>
<head>
    <title>Lista de Quejas y Reclamos</title>
    <link rel="stylesheet" href="<?php echo e(asset('Style/tablas.css')); ?>">

</head>
<?php $__env->startSection('content'); ?>

<body>
    <h1>Lista de Quejas y Reclamos</h1>
    
    <?php if(count($quejas) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Codigo SIS</th>
                    <th>Descripción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $quejas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($queja->Nombre); ?></td>
                        <td><?php echo e($queja->CodigoSIS); ?></td>
                        <td><?php echo e($queja->descripcion); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No hay quejas o reclamos registrados.</p>
    <?php endif; ?>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch/Documents/proyectosLaravel/tercerSprint/ProyectoParqueo/resources/views/reclamos/index.blade.php ENDPATH**/ ?>