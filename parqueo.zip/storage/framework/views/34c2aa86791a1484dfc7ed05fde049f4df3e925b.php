<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('Style/listaSol.css')); ?>">
</head>

<body>
  <!--
<div class="col-auto my-1">
 <a href="<?php echo e(route('solicitud.create')); ?>" class="btn btn-success">nuevo</a>
     </div>
-->
  <div class="container">
    <center>
      <label for="Titulo" class="Titulo">Lista del personal</label>
    </center>
    <div class="row">
      <div class="col-lx-12">
        <form action="<?php echo e(route('personal.index')); ?>" method="get">
          <div class="form-row">
            <div class="col-sm-4 my-1">
              <input type="text" class="form-control" name="texto" >
            </div>
            <div class="col-auto my-1">
              <input type="submit" class="btn btn-primary" value="buscar">
            </div>
          </div>
        </form>
      </div>
      <div class="col-lx-12">
        <div class="table-responsive">
          <table class="table table-striped">
                     
                <th></th>
                <th>Codigo SIS</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Email</th>
                <th>Telefono</th>
                <th>Cargo</th>
                <th>Turno</th>
    
            <tbody>
              <?php if(count($personale)<=0): ?>
              <tr>
                <td colspan="8">No hay resultados </td>
              </tr>
              <?php else: ?>

              <?php $__currentLoopData = $personale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="<?php echo e(route('personal.edit',$per->codigosispersonal)); ?>" class="btn btn-warning btn-sm">Editar</a>
                  <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($per->codigosispersonal); ?>">
                    Eliminar
                  </button>
                </td>
                <td><?php echo e($per->codigosispersonal); ?></td>
                <td><?php echo e($per->nombrepersonal); ?></td>
                <td><?php echo e($per->apellidopersonal); ?></td>
                <td><?php echo e($per->email); ?></td>
                <td><?php echo e($per->telefonopersonal); ?></td>
                <td><?php echo e($per->cargopersonal); ?></td>
                <td><?php echo e($per->turnopersonal); ?></td>
              </tr>
              <?php echo $__env->make('personal.eliminarpersonal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
          <?php echo e($personale->links()); ?>

        </div>
      </div>
    </div>
    <br>
    <div class="col-auto my-1 ">
      <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Volver a menu</a>
      <a href="<?php echo e(route('personal.create')); ?>" class="btn btn-primary">Ir a registro</a>
    </div>
    <br>
  </div>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch/Documents/proyectosLaravel/tercerSprint/ProyectoParqueo/resources/views/personal/listapersonal.blade.php ENDPATH**/ ?>