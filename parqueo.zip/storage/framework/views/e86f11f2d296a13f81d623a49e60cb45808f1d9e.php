<!DOCTYPE html>
<html>
<head>
    <title>Registro de Entrada</title>
    <link rel="stylesheet" href="<?php echo e(asset('Style/solicitud.css')); ?>">
</head>
<?php $__env->startSection('content'); ?>
<body>
    <?php if(session('error')): ?>
    <li><?php echo e(session('error')); ?></li>
    <?php endif; ?>
    <?php if(session('message')): ?>
    <li><?php echo e(session('message')); ?></li>
    <?php endif; ?>
    <h1>Registro de Entrada</h1>
    
    <form method="POST" action="<?php echo e(route('control.entrada', ['codigoSIS' => ''])); ?>">
        <?php echo csrf_field(); ?>
        <label for="codigoSIS">Código SIS:</label>
        <input type="text" name="codigoSIS" id="codigoSIS" required><br>
        <label for="">Hora de Entrada:</label><br>
        <input type="datetime-local" name="horaEntrada" id="horaEntrada" value="<?php echo e(now()); ?>"><br>
        <input type="submit" value="Registrar entrada">
    </form>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arch/Documents/proyectosLaravel/tercerSprint/ProyectoParqueo/resources/views/salidas_entradas/entrada.blade.php ENDPATH**/ ?>